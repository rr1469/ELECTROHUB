<footer>
		<div class="container-fluid">
			<center>Copyright@2020 | All Rights Reserve</center>
		</div>
</body>


<!-- Mirrored from demo.w3layouts.com/demos_new/template_demo/28-08-2018/electro_store-demo_Free/1204782700/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 20 Apr 2020 05:42:17 GMT -->
</html>