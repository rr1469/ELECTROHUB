    <?php
        include('header2.php');
        include('include/connection.php');
      ?>

      <?php 



if(isset($_POST["add_to_cart"]))
{
      $item_array = array(
        'item_id'     =>  $_GET["id"],
        'item_name'     =>  $_POST["hidden_name"],
        'item_price'    =>  $_POST["hidden_price"]
       
      );



       $query = 'INSERT INTO cart (cart_id ,item_id, item_name, item_price, username, checked_out)
  VALUES ("", '. $item_array["item_id"] .',"'. $item_array["item_name"] .'",'. $item_array["item_price"] .', "'. $_SESSION ["username"] .'", "2");
  ';
  $stmt = mysqli_query($conn, $query);
}


if(isset($_GET["action"]))
{
  if($_GET["action"] == "delete")
  {
    $query = 'DELETE FROM cart where cart_id = '. $_GET["id"] .';';
    $result = mysqli_query($conn, $query);
    echo '<script>alert("Item Removed")</script>';
    echo '<script>window.location="customer_panel.php"</script>';
      
  }
}


  if(isset($_GET["action"]))
  {
    if($_GET["action"] == "checkout")
    {
      $carts_query = 'UPDATE cart SET checked_out = "1" where checked_out = "2";';
      mysqli_query($conn, $carts_query); 
      unset($_SESSION["shopping_cart"]);
      header('location:checkout.php');
     
    }
  }

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Wlecome to SYB BarberShop</title>

    <script type="text/javascript">
function handleSelect(elm)
{
window.location = elm.value+".php";
}
</script>
    
  </head>
  <body>
    <br>
    <br>
    
     
    <br />
    <div class="container">
     <div class="card" style="width: 18rem;">
  <ul class="list-group list-group-flush">
     <li class="list-group-item">CATEGORY</li>
    <li class="list-group-item"><a href="male_hair.php">HAIR DESIGNS</a></li>
    <li class="list-group-item"><a href="male_beard.php">BEARD DESIGNS</a></li>
 
  </ul>
</div>
    
      <br />
      <br />
      <br />
      <h3 align="center">SYB Barber Services</h3><br />
      <br /><br />
      <?php
        $query = "SELECT * FROM tbl_product WHERE gender = 'Male'";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) > 0)
        {
          while($row = mysqli_fetch_array($result))
          {
        ?>
        

      <div class="col-md-4">
        <form method="post" action="customer_panel.php?action=add&id=<?php echo $row["id"]; ?>">
          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
            <img src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br />

            <h4 class="text-info"><?php echo $row["name"]; ?></h4>

            <h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
           

            <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

            <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

            <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

          </div>
        </form>
      </div>
      <?php
          }
        }
      ?>
      
      <div style="clear:both"></div>
      <br />
      <h3>Order Details</h3>
      <div class="table-responsive">
        <table class="table table-bordered">
          <tr>
            <th width="40%">Item Name</th>
           
            <th width="20%">Price</th>  
            <th width="15%">Total</th>
            <th width="5%">Action</th>
          </tr>
          <?php
          $query = 'SELECT * FROM cart where username = "' . $_SESSION ["username"] .'" and checked_out = "2";';
          $result = mysqli_query($conn, $query);
          if(!empty($result))
          {
            $total = 0;
            foreach($result as $keys => $values)   
            {
          ?>
          <tr>
            <td><?php echo $values["item_name"]; ?></td>           
            <td>$ <?php echo $values["item_price"]; ?></td>
            <td>$ <?php echo number_format( $values["item_price"], 2);?></td>
            <td><a href="customer_panel.php?action=delete&id=<?php echo $values["cart_id"]; ?>"><span class="text-danger">Remove</span></a>
                
            </td>

          </tr>
          <?php
              $total = $total +  $values["item_price"];
            }
          ?>
          <tr>
            <td colspan="2" align="right">Total</td>
            <td align="right">$ <?php echo number_format($total, 2); ?></td>
            <td><a href="customer_panel.php?action=checkout&username=<?php echo $_SESSION["username"]; ?>&total=<?php echo $total; ?>"><span ><button btn btn-primary>Checkout</button></span></a></td>
          </tr>
          <?php
          }
          ?>
            
        </table>
      </div>
    </div>
  </div>
  <br />
  </body>
  </html>
 <?php include('footer.php') ?>
      