<?php 
// include('includes/header.php');
include('includes/connection.php');
$errors = array();

   
if(isset($_POST['login']))
{

  $username=$_POST['username'];
  $password=$_POST['password'];
  $sql="select customer_id,username,password from customer where username='".$username."' && password='".$password."'";  
  $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0)
    {
      while($row = $result->fetch_assoc())
      {

      $_SESSION ['emp'] = $row['customer_id'];
      $_SESSION ['username'] = $username;
      $_SESSION ['password'] = $password;
      header('location:customer_panel.php');
     }
    }

   
        else
          {
            $sqlr="select admin_id,username,password from admin where username='".$username."' && password='".$password."'";  
                  $result=mysqli_query($conn,$sqlr);
                    if(mysqli_num_rows($result) > 0)
                {
                      while($row = $result->fetch_assoc())
                    {
                       $_SESSION ['admin'] = $row['admin_id'];
                      $_SESSION ['username'] = $username;
                      $_SESSION ['password'] = $password;
                      header('location:admin/index.php');

                     }
                }
                else{

                    echo "<script>alert('Invalid Username or Password')</script>";
                    }
            
          }         
  
      }
  

?>



<!DOCTYPE html>
<html>

<head>
  <title>Electro Store Ecommerce Category Bootstrap Responsive Web Template | Home :: w3layouts</title>
  <!-- Meta tag Keywords -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8" />
  <meta name="keywords" content="Electro Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
  />
  <script>
    addEventListener("load", function () {
      setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
      window.scrollTo(0, 1);
    }
  </script>
   <style type="text/css">
        .width{
            width: 400px;
            background: #fff;
            padding-bottom: 30px;
        }
        a:link {
  
  color: #fff;
}
    </style>
  <!-- //Meta tag Keywords -->

  <!-- Custom-Files -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
  <!-- Bootstrap css -->
  <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
  <!-- Main css -->
  <link rel="stylesheet" href="css/fontawesome-all.css">
  <!-- Font-Awesome-Icons-CSS -->
  <link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
  <!-- pop-up-box -->
  <link href="css/menu.css" rel="stylesheet" type="text/css" media="all" />
  <!-- menu style -->
  <!-- //Custom-Files -->

  <!-- web fonts -->
  <link href="http://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
      rel="stylesheet">
  <!-- //web fonts -->

</head>

<body>
  
</head>
<body class="bg-dark" style=" background-image: url('images/bg.jpg');">
  <div class="container width">
    <hr>
   
    <div class="row">
        <div class="col-sm-12">
     <center><h4>User Login</h4></center> 
     <hr>
    </div>
    <br>
    </div>
      <div class="col-sm-12">
            <form class="form-horizontal" action="" method="POST" id="loginForm">
              <fieldset>
                <div class="form-group">
                  <label for="username" class="col-sm-2 control-label">Username</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="username" name="username" placeholder="Username" autocomplete="off" required />
                  </div>
                </div>
                <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">Password</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" autocomplete="off" required />
                  </div>
                </div>                
                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    
                    <input type="submit" class="btn btn-primary" name="login" value="LOGIN">    
                    <a href="forgetpassword.php">| Forget Password</a>  <br> <br>
                    <a href="register.php">Register</a>  Don't have account?  
                     
                    
                  </div>
                  </div>
              </fieldset>
            </form>
          </div>
        </div>
        </div>
          <!-- panel-body -->
        

</body>
</html>

<?php
include('includes/footer.php');
?>







  