<?php
session_start();


include('includes/connection.php');
?>
<?php 

if(isset($_POST['submit']))
  {
    $username=$_POST['username'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];

    $query=mysqli_query($conn,"select * from customer where username = '$username' and email='$email' and phone='$phone' ");
    $ret=mysqli_fetch_array($query);

   

    if($ret>0){
      $username=$_POST['username'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
     header('location:resetpassword.php');
    }
    else{

      echo "<script>alert('Invalid User')</script>";
    }
  }
  ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    
    <title> Forget Password</title>
  

      <title>Change Password</title>

   <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
     <style type="text/css">
        .width{
            width: 400px;
            background: #fff;
            padding-bottom: 30px;
        }
        a:link {
            text-decoration: none;
  
  color: #fff;
}
    </style>    

</head>

<body class="bg-dark" style=" background-image: url('images/bg.jpg');">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container width">
            <div class="login-content">
                <div class="login-logo">
                    <hr>
                      <center><h3 style="color: Red">Customer Reset Password</h3></center>
                    <hr  color="red"/>
                </div>
                <div class="login-form">
                    <form action="" method="post" name="submit" style="50%">
                        <p style="font-size:16px; color:red" align="center"> 
                            <table class="table table-striped table-bordered table-hover">
                         <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" placeholder="Username" required="" name="username">
                        </div>
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" class="form-control" placeholder="Email" required="" name="email">
                        </div>
                            <div class="form-group">
                                <label>Mobile Number</label>
                                <input type="number" class="form-control" placeholder="Mobile Number" name="phone" required="">
                        </div>
                                
                                <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" name="submit">Reset</button> |
                               <a href="login.php">Back To login</a> 
                      
       
                            
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
