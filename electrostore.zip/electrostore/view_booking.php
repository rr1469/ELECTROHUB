      <?php
        include('includes/header1.php');
        include('includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
      </head>
      <body>
        <br>
        <br>
      <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">View Booking Details</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List of bookings
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
  
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <TH>Items Name</TH> 
                                        <TH>Total Price</TH>                                       
                                        <th>Status </th>   
                                        <th>Remarks </th>  
                                        <th>Order List </th>                                      
                                        
                                    </tr>
                                </thead>
<?php
$customer_name =  $_SESSION ['username'];


$r = "select * from booking where customer_name = '$customer_name'";
$result_booking = mysqli_query($conn,$r);

$r_c = "select * from cart where username = '$customer_name'";
$result_cart = mysqli_query($conn, $r_c);

while($row=mysqli_fetch_assoc($result_booking))
{
    echo "<tr>";
                echo "<td>".$row['booking_id']."</td>";                
                echo "<td>".$row['total_price']."</td>";
                if($row['status'] == "0") {
                    echo '<td style="color:orange;">Pending</td>';
                } else {
                    echo "<td style='color:green;'>".$row['status']."</td>";
                }

                

                echo "<td>".$row['comment']."</td>";
                                                  
              
                echo "<td> <a href=view_order.php?booking={$row['booking_id']}><button>View Ordered Item</button></a> 
                            ";
                echo "</tr>";   
}
echo"</table>";

?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    
    </body>
</html>
<?php include('includes/footer.php') ?>
      
      