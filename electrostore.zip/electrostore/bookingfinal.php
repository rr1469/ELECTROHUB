<?php Include('header2.php');
 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker1" ).datepicker();
  } );
  </script>

</head>
<body>

<?php 

         $username = $_GET['username'];
        if(isset($_POST["submit"])) {
             $booking_date =  $_POST['booking_date'];
             $shift =  $_POST['shift'];
             $comment =  $_POST['comment'];           
                   
           }     
        
 ?>

<div class="container">
  <h3>Booking Form</h3>
  <form method="post" action="booked.php">
    <label for="fname">Book Date</label>
    <input type="text" id="datepicker1" name="booking_date"  placeholder="Select Date you are looking for" value="">

    

    <label>Shift</label>

    <select  name="shift" value="">
      <option value="morning">Morning</option>
      <option value="Afternoon">Afternoon</option>
      <option value="Evening">Evening</option>
    </select>

    <label for="lname">Comment</label>
    <input type="text"  name="comment" placeholder="Comment" value="" >

    <label> Paying Total Amount </label>
    <input type="text"  name="total" readonly value="<?php echo $_GET['total']; ?>" >
    <input type="hidden"  name="username" readonly value="<?php echo $_GET['username']; ?>" >

    <input type="submit" value="Submit">
  </form>
</div>


</body>
<?php include('footer.php');?>
</html>
