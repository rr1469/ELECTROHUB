<?php 
include('includes/header1.php');
include('includes/connection.php');

if(isset($_POST["comment"]))
{

	$comment = $_POST["comment"];
  $username = $_POST["username"];
  $total = $_POST["total"];

     $query = 'INSERT INTO booking (booking_id,total_price,comment, customer_name, check_out)
  VALUES ("","'.$total.'","'.$comment.'","'.$username.'","0");';
  	// mysqli_query($conn, $query);

    if ($conn->query($query) === TRUE) {
      $booking_id = $conn->insert_id;
    }

    $query2 = 'UPDATE cart SET checked_out = "3" where username = "' . $username . '" and checked_out = "1";';
    mysqli_query($conn, $query2); 
  	$query3 = 'UPDATE cart SET booking_id = "'. $booking_id .'"  where checked_out = "3";';
    mysqli_query($conn, $query3);
  	$query4 = 'UPDATE cart SET checked_out = "0"  where checked_out = "3";';
    mysqli_query($conn, $query4);
  	header("Location: view_order.php?message=booked");

}
?>