<?php 
include('include/connection.php');

if(isset($_POST["booking_date"]))
{
	$date = $_POST["booking_date"];
	$shift = $_POST["shift"];
	$comment = $_POST["comment"];
  $username = $_POST["username"];
  $total = $_POST["total"];

     $query = 'INSERT INTO booking (booking_id ,booking_date, total_price, status, staff_id, comment, customer_name, check_out, shift)
  VALUES ("", "'. $date .'","'. $total .'","0","0","'. $comment .'","'. $username .'","0","'.$shift.'");';
  	// mysqli_query($conn, $query);

    if ($conn->query($query) === TRUE) {
      $booking_id = $conn->insert_id;
    }

    $query2 = 'UPDATE cart SET checked_out = "3" where username = "' . $username . '" and checked_out = "1";';
    mysqli_query($conn, $query2); 
  	$query3 = 'UPDATE cart SET booking_id = "'. $booking_id .'"  where checked_out = "3";';
    mysqli_query($conn, $query3);
  	$query4 = 'UPDATE cart SET checked_out = "0"  where checked_out = "3";';
    mysqli_query($conn, $query4);
  	echo '<script>alert("Thank you for booking with us.");</script>';
    header("Location: select_gender.php?message=booked");

}
?>