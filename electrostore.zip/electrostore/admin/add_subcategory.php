<?php

include('index.php');
include("../includes/connection.php");

?>


    <?php

    

        
        if (isset($_POST['submit'])) {
          // Get image name
             
          $subcategory_name = $_POST['subcategory_name'];

     

          $sql = "INSERT INTO category (subcategory_name) VALUES ('$subcategory_name')";
          // execute query
          mysqli_query($conn, $sql);

          echo "Category Successfully Added";
          }        

       
        
?>
<!DOCTYPE html>
<html>
<head>
<title>Add Category</title>

</head>
<body>
<div class="row">
  <div class="col-3">
  
  <form method="POST" action="add_category.php">
   <input type="text" name="subcategory_name">
      
   
      <button type="submit" name="submit" class="btn btn-success">POST</button>

    
  </form>
</div>
  </div>
</div>
</body>
</html>