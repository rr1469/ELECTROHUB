<!DOCTYPE html>
<html>
<head>
  <title>Change Password</title>
</head>
<body>

<?php 
include('master.php');

if($_POST)
{
  $opass = $_POST["opass"];
  $npass = $_POST["npass"];
  $cpass = $_POST["cpass"];
  $admin_id = $_SESSION ['admin'];
  $selectquery = mysqli_query($conn,"select password from admin where admin_id = '$admin_id'") or die(mysqli_error());

  $odata  = mysqli_fetch_row($selectquery);
  
  if($odata[0]==$opass)
  {
            if($npass==$cpass)
            {
              $q = mysqli_query($conn, "update admin set password = '{$npass}' where admin_id = '$admin_id'") or die(mysqli_error());
              if($q)
              {
                echo "<script>alert('Password Changed')</script>";
                
              }
            }
         else
          {
            echo "<script>alert('old Password and New Password not Match')</script>";
          }
        }
  else
    {
      echo "<script>alert('old Password not Match')</script>";
    }
}

 ?>

<div id="page-wrapper">
<TABLE class="table table-striped table-bordered table-hover" id="dataTables-example">
  <h3>Change Password??</h3>

<form method="post" >
   <tr>
        <td><label>Old Password</label></td>
        <td><input type="text" name="opass" placeholder="Enter old password"></td>
  </tr>
   <tr>
        <td><label>New Password</label></td>
        <td><input type="text" name="npass" placeholder="Enter New Password"></td>
  </tr>

   <tr>
        <td><label>Confirm Password</label></td>
        <td><input type="text" name="cpass" placeholder="Re-Enter New Password"></td>
  </tr>
         <tr>
          <td></td>        
        <td><input type="submit" class="btn btn-primary" style="width: 180px "></td>
  </tr>

</form>
</TABLE>
</div>
  

</body>
</html>