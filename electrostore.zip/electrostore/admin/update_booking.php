      <?php
        include('master.php');
        include('../include/connection.php');
        $booking_id = $_GET["booking_id"];
        $booked_product = 'SELECT * FROM cart where booking_id = "'. $booking_id .'";';
        $booked_product_list = mysqli_query($conn, $booked_product);
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
          <link rel="stylesheet" href="../css/jquery.timepicker.min.css">
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Update booking</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="col-md-offset-1 col-md-10">
    <?php

       $booking_id = $_GET['booking_id'];

        if(isset($_POST["submit"])) 
        {          
           
            $total_price = $_POST['total_price'];
            $status =  $_POST['status'];  
             $staff_id =  $_POST['staff_id'];          
            $comment =  $_POST['comment'];
             $start_time = $_POST['start_time'];
            $end_time = $_POST['end_time'];
          
            
            $sql=" UPDATE booking SET  total_price = '$total_price', status = '$status', staff_id = '$staff_id', comment='$comment', start_time='$start_time', end_time='$end_time' where booking_id = '$booking_id'" ;
            mysqli_query($conn,$sql);   
            echo "Data Updated.";
            echo "<meta http-equiv='refresh' content='0'>";
            
        }
        
        $result=" SELECT * FROM booking where booking_id = '$booking_id'";
        $r=mysqli_query($conn,$result);
        if($row=mysqli_fetch_assoc($r)) {
                
            $total_price = $row['total_price'];
             $staff_id = $row['staff_id'];
            $status =  $row['status'];           
            $comment =  $row['comment'];  
            $st = $row['start_time'];
            $et = $row['end_time'];        
         
        }

        $staff_query = 'SELECT * FROM staff where status = "Available";';
        $staff = mysqli_query($conn, $staff_query);
?>

<form method="post">
  <label>Total Price</label><input type="text" name="total_price" class="form-control" value="<?php echo $total_price?>"> <br>
  <label>Status</label><input type="text" name="status" class="form-control" value="<?php echo $status?>" ><br>

   <div class="form-group">
    <label for="usr">Start Time</label> &nbsp 
    <input type="text" class="form-control" name="start_time" id="timepick" value="<?php if($st) { echo $st; } ?>">
    <span class="input-group-addon">
      <span class="glyphicon glyphicon-time"></span>
    </span>
  </div>

  <div class="form-group">
    <label for="pwd">End Time</label> &nbsp 
    <input type="text" class="form-control" name="end_time" id="timepick2" value="<?php if($et) { echo $et; } ?>">
    <span class="input-group-addon">
      <span class="glyphicon glyphicon-time"></span>
    </span>
  </div>


  <label for="sel1">Staff</label>
  <select class="form-control" id="staff_id">
    <?php 
      foreach ($staff as $key => $value) {
         echo '<option value='.  $value["staff_id"] .'>' . $value["fullname"] . ' </option>';
      }
    ?>
  </select>
  <br/>
  <label>Comment</label><input type="text" name="comment"class="form-control" value="<?php echo $comment?>"><br>
  <input type="submit" class="btn btn-primary btn-lg" name="submit">
   &nbsp &nbsp &nbsp
   <button type="button" id="print" class="btn btn-primary btn-sm"> Print Bill </button>
</form>

<br />

<div class="table">
  <table class="table table-bordered" id="item_table">
    <thead>
      <tr>
        <th>Product Name</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($booked_product_list as $key => $value) {
          echo '<tr>
                <td>'. $value["item_name"] .'</td>
                <td>'. $value["item_price"] .'</td>
               </tr>';
      } ?>
    </tbody>
  </table>
</div>

</div>

</div>
    </body>
    <script src="../js/jquery.timepicker.min.js"></script>
    <script src="../js/printThis.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
          $('#timepick').timepicker({});
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){
          $('#timepick2').timepicker({});
        });
    </script>
    <script type="text/javascript">
    $(document).ready(function() {
      $( "#print" ).click(function() {
        $('#item_table').printThis();
      });
    });
</script>
</html>

      
      