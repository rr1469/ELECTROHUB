<?php
  include('include/connection.php');
  
?>
<!DOCTYPE html>
<html>
<head>
  <title>Signup</title>
   <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="glyphicon glyphicon-pencil"></i> User Registration</h3>
            <div class="container">
            <?php
                if(isset($_POST["submit"])) {
                  $username = $_POST["username"];
                  $email = $_POST["email"];
                  $password = $_POST["password"];
                  $name = $_POST["name"];                  
                  $phone =  $_POST['phone'];
                  $error="";

                    $query=mysqli_query($conn,"select * from customer where username = '$username' and email='$email' ");
                    $ret=mysqli_fetch_array($query);

                    if ($ret>0) {
                      echo "<script>alert('Username or email already registered')</script>";
                    }
                    else
                    {                  
                  if($error==""){
                  
                  $sql = " INSERT INTO customer(username, email, password, name, phone) VALUES                          
                  ('$username', '$email', '$password','$name', '$phone')";
                  
                  $r = mysqli_query($conn,$sql) or die(mysqli_error());             

              
                  echo "<script>alert('Congratulation you are registered')</script>";
                  header('location:login.php');
                }else {
                    echo $error;  
                  }
                }
              }

             
                ?>
              <form method="POST">
               <label><h3>Employee Information</h3></label>

               <div class="form-group row">
                    <label for="lgFormGroupInput" class="col-sm-2 col-form-label col-form-label-sm">Username</label>
                          <div class="col-sm-10">
                              <input type="text" name="username" class="form-control form-control-lg" id="lgFormGroupInput" placeholder="No Space Recommended">
                          </div>
                </div>

                <div class="form-group row">
                    <label for="lgFormGroupInput" class="col-sm-2 col-form-label col-form-label-sm">Password</label>
                          <div class="col-sm-10">
                              <input type="password" name="password" class="form-control form-control-lg" id="lgFormGroupInput" placeholder="Enter New Password">
                          </div>
                </div>


                <div class="form-group row">
                    <label for="lgFormGroupInput" class="col-sm-2 col-form-label col-form-label-sm">Full Name</label>
                          <div class="col-sm-10">
                              <input type="text" name="name" class="form-control form-control-lg" id="lgFormGroupInput" placeholder="Enter Full Name">
                          </div>
                </div>

                <div class="form-group row">
                    <label for="lgFormGroupInput" class="col-sm-2 col-form-label col-form-label-sm">Email</label>
                          <div class="col-sm-10">
                              <input type="email" name="email" class="form-control form-control-lg" id="lgFormGroupInput" placeholder="Enter valid email">
                          </div>
                </div>


                

                 <div class="form-group row">
                    <label for="lgFormGroupInput" class="col-sm-2 col-form-label col-form-label-sm">phone</label>
                          <div class="col-sm-10">
                              <input type="number" name="phone" class="form-control form-control-lg" id="lgFormGroupInput" placeholder="Enter Full Name">
                          </div>
                </div>

               
                

                        <div class="col-sm-offset-6 form-control-lg-7">
                            <input type="submit" class="btn btn-success" name="submit" value="SignUp"> 
                            <button value="Back To Login"><a href="index.php">Back To login</a></button>                
                        </div>
                </div>  

              </form>
              </center>
            </div>

                </div> 
                <!-- /.col-lg-12 -->
            </div>
        </div>
        
   
</body>
</html>

