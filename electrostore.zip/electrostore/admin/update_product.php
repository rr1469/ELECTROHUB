      <?php
        include('index.php');
        include('../includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Update Product</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="col-md-offset-1 col-md-10">
    <?php

        $pid = $_GET['id'];
       
        if(isset($_POST["submit"])) 
        {          
                   
                $name =  $_POST['name'];
               $details =  $_POST['details'];              
               $price =  $_POST['price'];
               $category= $_POST['category'];
          
            
            $sql=" UPDATE tbl_product SET  name = '$name', details = '$details', price = '$price', category='$category' where id = '$pid'" ;
            mysqli_query($conn,$sql);   
            echo "Data Updated.";
            
        }
        
        $result=" SELECT * FROM tbl_product where id = '$pid'";
        $r=mysqli_query($conn,$result);
        if($row=mysqli_fetch_assoc($r)) {
                
             $name =  $row['name'];      
             $details =  $row['details'];              
               $price =  $row['price'];
               $category= $row['category'];      
         
        }

      
?>

<form method="POST">

  <label>Name</label><input type="text" name="name" class="form-control" value="<?php echo $name?>"> <br>
  <label>Details</label><input type="text" name="details" class="form-control" value="<?php echo $details?>"> <br>
  <label>price</label><input type="number" name="price" class="form-control" value="<?php echo $price?>" ><br>

   <label>Category</label><input type="text" name="category"class="form-control" value="<?php echo $category?>"><br>
  <br/>
    <input type="submit" class="btn btn-primary btn-lg" name="submit">
</form>
<br />
<br />

</div>

</div>
    </body>
</html>

      
      