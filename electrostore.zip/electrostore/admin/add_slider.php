<?php

include('index.php');
include("../includes/connection.php");

?>


    <?php

     $msg = "";

        // If upload button is clicked ...
        if (isset($_POST['upload'])) {
          // Get image name
          $image = $_FILES['image']['name'];
          $name = $_POST['name'];          
    

          // Get text
          // image file directory
          $target = "../images/".basename($image);
          

          $sql = "INSERT INTO banner (name,image) VALUES ('$name','$image')";
          // execute query
          mysqli_query($conn, $sql);

          if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $msg = "Image uploaded successfully";
          }else{
            $msg = "Failed to upload image";
          }
        }
        $result = mysqli_query($conn, "SELECT * FROM banner");

       
        
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>

</head>
<body>
<div id="content">
  
  <form method="POST" action="add_slider.php" enctype="multipart/form-data" style="width: 600px">
    <input type="hidden" name="size" value="1000000" class="form-control" >
    <div>
      <input type="file" name="image" >
    </div>
    
   <label>Image Name</label> <input type="text" name="name" class="form-control" > <br>

    <div>
      <button type="submit" name="upload">POST</button>
    </div>
  </form>
</div>
</body>
</html>