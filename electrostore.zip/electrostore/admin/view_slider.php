    <?php
        include('index.php');
        include('../includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>

         <style type="text/css">
}
  
   #img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width:100px;
    height: 100px;
   }
</style>

      </head>
      <body>
      <div id="content-wrapper">
         
        
  
                            <table  class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                      
                                        <th>Slider Image</th>
                                        <th>Slider Title</th>
                                        <th>Image Name</th>
                                        <th>Remarks</th>                               
                                    </tr>
                                </thead>

          
                     
  <?php
  if(isset($_GET["action"])){
    $action=$_GET["action"];
    if($action=="delete"){
        $id=$_GET["id"];
        $sqlpro = "delete from banner where id=".$id;
        $sql="delete from banner where id='$id'";
        mysqli_query($conn,$sqlpro);
        $result=mysqli_query($conn,$sql);
    }
}


$r="select * from banner";
$result = mysqli_query($conn,$r);
  
    while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";




               echo "<td><img src='../images/".$row['image']."' ></td>";
               echo "<td>".$row['name']."</td>";                
                echo "<td>".$row['image']."</td>";

                echo "<td><a href=view_slider.php?action=delete&id={$row['id']}><button>Delete</button></a>
                            ";

   
    echo "</tr>";   
}
echo"</table>";

?>

</table>


          

   
</html>
 
      