    <?php
        include('index.php');
        include('../includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>

         <style type="text/css">
}
  
   #img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width:100px;
    height: 100px;
   }
</style>

      </head>
      <body>
      <div id="content-wrapper">
         
        
  
                            <table  class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                      
                                        <th>Category Name</th>                                       
                                        <th>Remarks</th>                               
                                    </tr>
                                </thead>

          
                     
  <?php
  if(isset($_GET["action"])){
    $action=$_GET["action"];
    if($action=="delete"){
        $cat_id=$_GET["id"];  
        $sqlpro = "delete from category where cat_id=".$cat_id;
        $sql="delete from category where cat_id='$cat_id'";
        mysqli_query($conn,$sqlpro);
        $result=mysqli_query($conn,$sql);
    }
}


$r="select * from category";
$result = mysqli_query($conn,$r);
  
    while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";

             
               echo "<td>".$row['category_name']."</td>";                
              

                echo "<td>
                <a href=update_category.php?action=update&cat_id={$row['cat_id']}><button>Update</button></a> 
                <a href=view_category.php?action=delete&id={$row['cat_id']}><button>Delete</button></a>
                            ";

   
    echo "</tr>";   
}
echo"</table>";

?>

</table>


          
</div>
</body>

   
</html>
 
      