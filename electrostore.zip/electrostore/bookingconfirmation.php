<?php 

include('includes/header1.php');
include('includes/connection.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="assests/bootstrap/css/bootstrap.min.css">

	<style type="text/css">
		
		#btn{

			background-color: red;
			width: 150px;
			padding: 20px;
			color:white;
			font-size: 30px;

			}
		.success{

			color: green;
		}

		.
	</style>
</head>
<body background="red">
<br>

<br>
<br>

<br>

<br>

<br>

<br>

<br>

<br>

<br>

<center>

	

	<?php 

		if (isset($_GET["message"])) {
			echo 'Booking Successful';
		} else {
			echo 'Booking failed';
		}
	 ?>

	 
	</center>

</body>
</html>