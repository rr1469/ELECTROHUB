   <?php
        include('includes/header1.php');
        include('includes/connection.php');
        ob_start();
      ?>
<!DOCTYPE html>
<html>
<head>
  <title>Electrostore</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker1" ).datepicker();
  } );
  </script>
  <style type="text/css">
    .next {
  background-color: #4CAF50;
  color: white;
  </style>

</head>

<body>

<div id="page-wrapper">
          

    <div class="container" style="width: 600px">

       <h3 class="page-header"><i class="fa fa-pencil"> </i> Book Time & Date</h3>
      <div style="clear:both"></div>
      <form method="POST">
      <br />
      <h3>Order Details</h3>
      <div class="table-responsive">
        <table class="table table-bordered">
          <tr>
            <th width="40%">Item Name</th>
           
            <th width="20%">Price</th>  
            <th width="15%">Total</th>
            <th width="5%">Action</th>
          </tr>
          <?php
          if(isset($_GET["action"]))


            {
              if($_GET["action"] == "delete")
              {
                $query = 'DELETE FROM cart where cart_id = '. $_GET["id"] .';';
                $result = mysqli_query($conn, $query);
                echo '<script>alert("Item Removed")</script>';
                echo '<script>window.location="checkout.php"</script>';
                  
              }
            }
          $query = 'SELECT * FROM cart where username = "' . $_SESSION ["username"] .'" and checked_out = "1";';
          $result = mysqli_query($conn, $query);
          if(!empty($result))
          {
            $total = 0;
            foreach($result as $keys => $values)   
            {
          ?>
          <tr>
            <td><?php echo $values["item_name"]; ?></td>           
            <td>$ <?php echo $values["item_price"]; ?></td>
            <td>$ <?php echo number_format( $values["item_price"], 2);?></td>
            <td><a href="checkout.php?action=delete&id=<?php echo $values["cart_id"]; ?>"><span class="text-danger">Remove</span></a>                
            </td>

          </tr>
          <?php
              $total = $total +  $values["item_price"];
            }
          ?>
          <tr>
            <td colspan="3" align="right">Total Paying Amount</td>
            <td align="right">$ <?php echo number_format($total, 1); ?></td>
            
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td><a href="bookingfinal.php?&username=<?php echo $values["username"]; ?>&total=<?php echo $total ?>" class="next">Next </a></td>
          </tr>
          
          <?php
          }
          ?>

            
        </table>
      </div>  
      <div table-responsive>

      </div>
    </form>
  </div>
</div>

            




</body>
</html>

<?php
include('includes/footer.php');
 ?>

