      <?php
        include('includes/header1.php');
        include('includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">View Orders</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List of Orders
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
  
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
<?php
$booking_id =  $_GET['booking'];
$r = "select * from cart where booking_id = '$booking_id'";
$result_booking = mysqli_query($conn,$r);

while($row=mysqli_fetch_assoc($result_booking))
{
    echo "<tr>";
        echo "<td>".$row['item_name']."</td>";
        echo "<td>".$row['item_price']."</td>";
    echo "</tr>";   
}
echo"</table>";

?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    
    </body>
</html>
<?php include('includes/footer.php') ?>
      
      