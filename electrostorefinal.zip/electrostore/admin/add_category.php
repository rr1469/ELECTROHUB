<?php

include('index.php');
include("../includes/connection.php");

?>


    <?php

    

        
        if (isset($_POST['submit'])) {
          // Get image name
             
          $category_name = $_POST['category_name'];

     

          $sql = "INSERT INTO category (category_name) VALUES ('$category_name')";
          // execute query
          mysqli_query($conn, $sql);

          echo "Category Successfully Added";
          }        

       
        
?>
<!DOCTYPE html>
<html>
<head>
<title>Add Category</title>

</head>
<body>
<div class="row">
  <div class="col-6">
  
  <form method="POST" action="add_category.php">
   <input type="text" name="category_name">
      
   
      <button type="submit" name="submit" class="btn btn-success">POST</button>

    
  </form>
</div>
  </div>
</div>
</body>
</html>