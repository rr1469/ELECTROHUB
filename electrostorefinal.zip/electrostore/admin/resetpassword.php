
<!doctype html>
<html class="no-js" lang="en">
<head>
   
    <title>Forgot Password</title>
  
   <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</head>

<body class="bg-dark" style=" background-image: url('images/bg.jpg');">


    <div class="sufee-login d-flex align-content-Right flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                <h3 style="color: red">Reset Password </h3>
                    <hr  color="red"/>
                </div>
                <div class="login-form">
                    <form action="" method="post" name="changepassword" onsubmit="return checkpass();">
                        <p style="font-size:16px; color:red" align="center"> 
 </p>
                        <div class="form-group">
                            <?php
                                session_start();
                                include('include/connection.php');

                                if(isset($_POST['submit']))
                                  {
                                    $phone=$_SESSION['phone'];
                                    $email=$_SESSION['email'];
                                    $password=$_POST['newpassword'];
                                    $pass=$_POST['confirmpassword'];
                                    if ($password == $pass) {

                                        $query=mysqli_query($conn,"update customer set Password='$password'  where  email='$email' && phone='$phone' ");
                                           if($query)
                                           {
                                        echo "<script>alert('Password successfully changed');</script>";

                                        header('location:index.php');
                                        session_destroy();

                                            }

                                    
                                   }else
                                   {
                                    echo "New password and Confirm password don't match";
                                   }
                                  
                                  }
                                  ?>

                                <label class="col-sm-2 control-label">New Password</label>
                                <input type="password" class="form-control" placeholder="New Password" name="newpassword" required="">
                        </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Confirm Your Password</label>
                                <input type="password"  class="form-control" placeholder="Confirm Your Password" name="confirmpassword" required="">
                        </div>
                               
                                <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" name="submit">Reset</button>
                                <button value="Back To Login"><a href="index.php">Back To login</a></button> 
                                
                            
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
