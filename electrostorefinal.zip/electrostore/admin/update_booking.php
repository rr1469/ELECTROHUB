      <?php
        include('index.php');
        include('../includes/connection.php');
        $booking_id = $_GET["booking_id"];
        $booked_product = 'SELECT * FROM cart where booking_id = "'. $booking_id .'";';
        $booked_product_list = mysqli_query($conn, $booked_product);
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
         
          <script src="../js/jquery.timepicker.min.js"></script>
    <script src="../js/printThis.js"></script>   
  
    <script type="text/javascript">
    $(document).ready(function() {
      $( "#print" ).click(function() {
        $('#item_table').printThis();
      });
    });
</script>
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Update booking</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="col-md-offset-1 col-md-10">
    <?php

       $booking_id = $_GET['booking_id'];

        if(isset($_POST["submit"])) 
        {          
           
          
            $status =  $_POST['status'];               
          
            
            $sql=" UPDATE booking SET  status = '$status' where booking_id = '$booking_id'" ;
            mysqli_query($conn,$sql);   
            echo "Data Updated.";
            echo "<meta http-equiv='refresh' content='0'>";
            
        }
        
        $result=" SELECT * FROM booking where booking_id = '$booking_id'";
        $r=mysqli_query($conn,$result);
        if($row=mysqli_fetch_assoc($r)) {
                
           
            $status =  $row['status'];           
                
         
        }

      
?>

<form method="post">
  
  <label>Status</label>
  <select name="status">
    <option>Delivered</option>
    <option>Not Delivered</option>
    
  </select>
  <br>



  
  
  <input type="submit" class="btn btn-primary btn-lg" name="submit">
   &nbsp &nbsp &nbsp
   <button type="button" id="print" class="btn btn-primary btn-sm"> Print Bill </button>
</form>

<br />

<div class="table">
  <table class="table table-bordered" id="item_table">
    <thead>
      <tr>
        <th>Product Name</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($booked_product_list as $key => $value) {
          echo '<tr>
                <td>'. $value["item_name"] .'</td>
                <td>'. $value["item_price"] .'</td>
               </tr>';
      } ?>
    </tbody>
  </table>
</div>

</div>

</div>
    </body>
    
</html>

      
      