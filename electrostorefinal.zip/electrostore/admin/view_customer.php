      <?php
        include('index.php');
        include('../includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">View Customer Details</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List of Customers
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
  
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Customer ID</th>
                                        <th>Full Name</th>
                                        <th>Email</th>
                                        <th>Username</th>
                                        <TH>password</TH>
                                        <TH>Phone</TH>                                       
                                        <th>Gender </th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
<?php
if(isset($_GET["action"])){
    $action=$_GET["action"];
    if($action=="delete"){
        $customer_id=$_GET["customer_id"];
        $sqlpro = "delete from customer where customer_id=".$customer_id;
        $sql="delete from customer_id where customer_id='$customer_id'";
        mysqli_query($conn,$sqlpro);
        $result=mysqli_query($conn,$sql);
    }
}


$r="select * from customer";
$result = mysqli_query($conn,$r);

while($row=mysqli_fetch_assoc($result))
{
    echo "<tr>";
                echo "<td>".$row['customer_id']."</td>";
                echo "<td>".$row['name']."</td>";
                echo "<td>".$row['email']."</td>";
                echo "<td>".$row['username']."</td>"; 
                echo "<td>".$row['password']."</td>";
                echo "<td>".$row['phone']."</td>";
                echo "<td>".$row['gender']."</td>";


                                  
              
                echo "<td> <a href=update_customer.php?action=update&customer_id={$row['customer_id']}><button>Update</button></a> 
                            <a href=view_customer.php?action=delete&customer_id={$row['customer_id']}><button>Delete</button></a>
                            ";
                echo "</tr>";   
}
echo"</table>";

?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    
    </body>
</html>

      
      