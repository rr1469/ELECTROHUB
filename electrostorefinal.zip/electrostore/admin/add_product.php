<?php

include('index.php');
include("../includes/connection.php");

?>


    <?php

     $msg = "";

        // If upload button is clicked ...
        if (isset($_POST['upload'])) {
          // Get image name
          $image = $_FILES['image']['name'];
          $name = $_POST['name'];          
          $price = $_POST['price'];         
          $category = $_POST['category'];

          // Get text
          $details = mysqli_real_escape_string($conn, $_POST['details']);

          // image file directory
          $target = "../images/".basename($image);
          

          $sql = "INSERT INTO tbl_product (name,image, details, price, category) VALUES ('$name','$image', '$details','$price','$category')";
          // execute query
          mysqli_query($conn, $sql);

          if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $msg = "Image uploaded successfully";
          }else{
            $msg = "Failed to upload image";
          }
        }
        $result = mysqli_query($conn, "SELECT * FROM tbl_product");

       
        
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>

</head>
<body>
<div id="content">
  
  <form method="POST" action="add_product.php" enctype="multipart/form-data" style="width: 600px">
    <input type="hidden" name="size" value="1000000" class="form-control" >
    <div>
      <input type="file" name="image" >
    </div>
    <div>
      <textarea 
        id="text" 
        cols="40" 
        rows="4" 
        name="details" 
        placeholder="Say something about this image..."></textarea>
    </div>
   <label>Product Name</label> <input type="text" name="name" class="form-control" > <br>

     <label>Price</label> <input type="number" name="price" class="form-control" ><br>

       <br>
       <label>Category
     <SELECT name="category">
      <option>Samsung</option><br />
     <option>Apple</option><br />    
     </SELECT>
     </label><br />
    <div>
      <button type="submit" name="upload">POST</button>
    </div>
  </form>
</div>
</body>
</html>