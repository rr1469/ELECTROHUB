      <?php
        include('index.php');
        include('../includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Update Customer</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="col-md-offset-1 col-md-10">
    <?php
            $customer_id=$_GET["customer_id"];
        if(isset($_POST["submit"])) 
        {

            
             $username =  $_POST['username'];
             $password =  $_POST['password'];
             $name =  $_POST['name']; 
             $email = $_POST['email'];            
             $phone= $_POST['phone'];
            
                   
          
            
            $sql=" UPDATE customer SET  username='$username', password = '$password', name='$name', email='$email', phone = '$phone' WHERE customer_id=$customer_id" ;
            mysqli_query($conn,$sql);   
            echo "Data Updated.";
            
        }
        
        $result=" SELECT * FROM customer WHERE customer_id='$customer_id'";
        $r=mysqli_query($conn,$result);
        if($row=mysqli_fetch_assoc($r)) {
              $username =  $row['username'];
              $password =  $row['password'];
              $name =  $row['name']; 
              $email = $row['email'];            
              $phone= $row['phone'];
          
         
        }
?>
<br />
<br />
<table>
  <tr>
       <form name="frm1" method="post"  id="add_staff">

<label>Username</label><br />
<input type="text" name="username" class="form-control" value="<?php echo $username  ?>"> <br />


<label>Password</label><br />
<input type="text" name="password" class="form-control" value="<?php echo $password  ?>"> <br />

 <label>Full Name</label> <br />
 <input type="text" name="name" class="form-control" value="<?php echo $name  ?>"><br />

<label>email</label><br />
 <input type="text"  class="form-control" name="email" value="<?php echo $email  ?>" ><br />
 
 <label>phone</label><br />
 <input type="text"  class="form-control" name="phone" value="<?php echo $phone  ?> "><br />

  
   <input type="submit" name="submit" value="Submit" class="btn btn-success btn-lg" />
 </form>
         </tr>
 </table>
</div>

</div>
    </body>
</html>

      
      