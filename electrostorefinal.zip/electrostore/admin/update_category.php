      <?php
        include('index.php');
        include('../includes/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>
      </head>
      <body>
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h5>Update category</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="col-md-offset-1 col-md-4">
    <?php
            $cat_id=$_GET["cat_id"];
        if(isset($_POST["submit"])) 
        {

            
             $category_name =  $_POST['category_name'];
             
                   
          
            
            $sql=" UPDATE category SET  category_name='$category_name' WHERE cat_id=$cat_id" ;
            mysqli_query($conn,$sql);   
            echo "Data Updated.";
            
        }
        
        $result=" SELECT * FROM category WHERE cat_id='$cat_id'";
        $r=mysqli_query($conn,$result);
        if($row=mysqli_fetch_assoc($r)) {
              $category_name =  $row['category_name'];            
         
        }
?>
<br />
<br />
<table>
  <tr>
       <form name="frm1" method="post">

<label>category_name</label><br />
<input type="text" name="category_name" class="form-control" value="<?php echo $category_name  ?>"> <br />
  
   <input type="submit" name="submit" value="Submit" class="btn btn-success btn-lg" />
 </form>
         </tr>
 </table>
</div>

</div>
    </body>
</html>

      
      