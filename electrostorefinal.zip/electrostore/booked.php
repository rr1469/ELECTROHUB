<?php 
include('includes/header1.php');
include('includes/connection.php');

if(isset($_POST["shipping_address"]))
{

	$card_number = $_POST["card_number"];
  $expiry_date = $_POST["expiry_date"];
  $cvv = $_POST["cvv"];
  $shipping_address = $_POST["shipping_address"];
  $username = $_POST["username"];
  $total = $_POST["total"];

     $query = 'INSERT INTO booking(booking_id,total_price,shipping_address,expiry_date,cvv,card_number, customer_name, check_out)
  VALUES ("","'.$total.'","'.$shipping_address.'","'.$expiry_date.'","'.$cvv.'","'.$card_number.'","'.$username.'","0");';
  	// mysqli_query($conn, $query);

    if ($conn->query($query) === TRUE) {
      $booking_id = $conn->insert_id;
    }

    $query2 = 'UPDATE cart SET checked_out = "3" where username = "' . $username . '" and checked_out = "1";';
    mysqli_query($conn, $query2); 
  	$query3 = 'UPDATE cart SET booking_id = "'. $booking_id .'"  where checked_out = "3";';
    mysqli_query($conn, $query3);
  	$query4 = 'UPDATE cart SET checked_out = "0"  where checked_out = "3";';
    mysqli_query($conn, $query4);
  	header("Location: view_booking.php?message=booked");

}
?>