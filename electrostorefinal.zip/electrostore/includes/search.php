<?php
include('includes/connection.php');
if(isset($_GET['submit'])){
$name = $_GET['name];
$sql = "select * from tbl_product where name like '$name%'";
$result = mysqli_query($conn,"$sql");
while($row=mysqli_fetch_array($result)){

?>

<?php echo $row['name'];?>