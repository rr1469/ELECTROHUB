
<?php
session_start();
if(!isset($_SESSION  ['username']['customer_id'])) {	
  header('location:../login.php'); 
}

?>


?>


<?php
session_start();
if(!isset($_SESSION  ['username']['admin_id'])) {	
  header('location:index.php'); 
}

?>





