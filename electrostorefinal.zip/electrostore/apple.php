
  <?php
      include('includes/connection.php');
      include('includes/header.php');
      ?>
     

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

    <link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
  <!-- bootstrap theme-->
  <link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
  <!-- font awesome -->
  <link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">


    <script type="text/javascript">
function handleSelect(elm)
{
window.location = elm.value+".php";
}
</script>
</head>
<body>

	<div class="ads-grid py-sm-5 py-4">
		<div class="container py-xl-4 py-lg-2">
			<!-- tittle heading -->
			<h3 class="tittle-w3l text-center mb-lg-5 mb-sm-4 mb-3">
				<span>O</span>ur
				<span>N</span>ew
				<span>P</span>roducts</h3>
			<!-- //tittle heading -->
			<div class="row">
				<!-- product left -->
				<div class="agileinfo-ads-display col-lg-12">
					<div class="wrapper">
						
						<div class="container">
        <table>
      <tr>
        
<td>
    
      <?php
        $query = "SELECT * FROM tbl_product where category='Apple'";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) > 0)
        {
          while($row = mysqli_fetch_array($result))
          {
        ?>
                

      <div class="col-md-6">
        <form method="post" action="login.php">
          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
            <img src="images/<?php echo $row["image"]; ?>" width="200px" heigt="200px" class="img-responsive" /><br />

            <h4 class="text-info"><?php echo $row["name"]; ?></h4>

            <h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
           

            <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

            <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

            <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

          </div>
          <br>
        </form>
      </div>
      <?php
          }
        }
      ?>
    </td></tr></table>
      
      </div>
    </div>
  </div>
  <br />
				</div>
				

				
				</div>
			</div>
		</div>
	</div>
	<!-- //top products -->

</body>
<?php 



if(isset($_POST["add_to_cart"]))
{
      $item_array = array(
        'item_id'     =>  $_GET["id"],
        'item_name'     =>  $_POST["hidden_name"],
        'item_price'    =>  $_POST["hidden_price"]
       
      );



       $query = 'INSERT INTO cart (cart_id ,item_id, item_name, item_price, username, checked_out)
  VALUES ("", '. $item_array["item_id"] .',"'. $item_array["item_name"] .'",'. $item_array["item_price"] .', "'. $_SESSION ["username"] .'", "2");
  ';
  $stmt = mysqli_query($conn, $query);
}


if(isset($_GET["action"]))
{
  if($_GET["action"] == "delete")
  {
    $query = 'DELETE FROM cart where cart_id = '. $_GET["id"] .';';
    $result = mysqli_query($conn, $query);
    echo '<script>alert("Item Removed")</script>';
    echo '<script>window.location="customer_panel.php"</script>';
      
  }
}


  if(isset($_GET["action"]))
  {
    if($_GET["action"] == "checkout")
    {
      $carts_query = 'UPDATE cart SET checked_out = "1" where checked_out = "2";';
      mysqli_query($conn, $carts_query); 
      unset($_SESSION["shopping_cart"]);
      header('location:checkout.php');
     
    }
  }

?>
</html><!-- top Products -->
	