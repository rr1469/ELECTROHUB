
         <?php
        include('includes/header1.php');
        include('includes/connection.php');
      ?>
      <div class="container">
      <br />
      <h3>Order Details</h3>
      <div class="table-responsive">
        <table class="table table-bordered">
          <tr>
            <th width="40%">Item Name</th>
           
            <th width="20%">Price</th>  
            <th width="15%">Total</th>
            <th width="5%">Action</th>
          </tr>
          <?php
          $query = 'SELECT * FROM cart where username = "' . $_SESSION ["username"] .'" and checked_out = "2";';
          $result = mysqli_query($conn, $query);
          if(!empty($result))
          {
            $total = 0;
            foreach($result as $keys => $values)   
            {
          ?>
          <tr>
            <td><?php echo $values["item_name"]; ?></td>           
            <td>$ <?php echo $values["item_price"]; ?></td>
            <td>$ <?php echo number_format( $values["item_price"], 2);?></td>
            <td><a href="customer_panel.php?action=delete&id=<?php echo $values["cart_id"]; ?>"><span class="text-danger">Remove</span></a>
                
            </td>

          </tr>
          <?php
              $total = $total +  $values["item_price"];
            }
          ?>
          <tr>
            <td colspan="2" align="right">Total</td>
            <td align="right">$ <?php echo number_format($total, 2); ?></td>
            <td><a href="customer_panel.php?action=checkout&username=<?php echo $_SESSION["username"]; ?>&total=<?php echo $total; ?>"><span ><button btn btn-primary>Checkout</button></span></a></td>
          </tr>
          <?php
          }
          ?>
            
        </table>