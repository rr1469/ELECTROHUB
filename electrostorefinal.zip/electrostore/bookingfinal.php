<?php Include('includes/header1.php');
include('includes/connection.php');
 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script>
  $( function() {
    $( "#datepicker1" ).datepicker();
  } );
  </script>

</head>
<body>

<?php 

         $username = $_GET['username'];
        if(isset($_POST["submit"])) {

             $shipping_address =  $_POST['shipping_address'];
             $card_number =  $_POST['card_number'];
             $expiry_date =  $_POST['expiry_date'];  
             $cvv =  $_POST['cvv'];         
                   
           }     
        
 ?>

<div class="container">
  <center><h3>Checkout</h3></center>
  <form method="post" action="booked.php">    

    <label for="lname">Card Number</label>
    <input type="text"  name="card_number" placeholder="Enter Card Number" value="" required >

    <label for="lname">Expiry Date</label>
    <input type="text" id="datepicker1" name="expiry_date" placeholder="Expiry Date" value="" >

    <label for="lname">CVV Number</label>
    <input type="text"  name="cvv" placeholder="CVV number" value="" >

    <label for="lname">Shipping Address</label>
    <input type="text"  name="shipping_address" placeholder="Enter your Shipping Address" value="" >

    <label> Paying Total Amount </label>
    <input type="text"  name="total" readonly value="<?php echo $_GET['total']; ?>" >
    <input type="hidden"  name="username" readonly value="<?php echo $_GET['username']; ?>" >

    <input type="submit" value="Submit">
  </form>
</div>


</body>
<?php include('includes/footer.php');?>
</html>
