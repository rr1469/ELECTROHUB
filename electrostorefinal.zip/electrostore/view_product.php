    <?php
        include('master.php');
        include('../include/connection.php');
      ?>

      <!DOCTYPE html>
      <html>
      <head>
          <title></title>

         <style type="text/css">
}
  
   #img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width:100px;
    height: 100px;
   }
</style>

      </head>
      <body>
      <div id="content-wrapper">
         
        
  
                            <table  class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                      
                                        <th>Product Image</th>
                                        <th>Product Name</th>
                                        <th>Product Details</th>
                                        <th>Gender</th>    
                                        <th>Price</th> 
                                        <th>Face Suitable for</th>     
                                        <th>Remarks</th>                               
                                    </tr>
                                </thead>

          
                     
  <?php
  if(isset($_GET["action"])){
    $action=$_GET["action"];
    if($action=="delete"){
        $id=$_GET["id"];
        $sqlpro = "delete from tbl_product where id=".$id;
        $sql="delete from tbl_product where id='$id'";
        mysqli_query($conn,$sqlpro);
        $result=mysqli_query($conn,$sql);
    }
}


$r="select * from tbl_product";
$result = mysqli_query($conn,$r);
  
    while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";




               echo "<td><img src='../images/".$row['image']."' ></td>";
               echo "<td>".$row['name']."</td>";
                echo "<td>".$row['details']."</td>";
               echo "<td>".$row['gender']."</td>";
                echo "<td>".$row['price']."</td>";
                echo "<td>".$row['facetype']."</td>";

                echo "<td> <a href=update_design.php?action=update&id={$row['id']}><button>Update</button></a> 
                            <a href=view_product.php?action=delete&id={$row['id']}><button>Delete</button></a>
                            ";

   
    echo "</tr>";   
}
echo"</table>";

?>

</table>


          

   
</html>
 
      