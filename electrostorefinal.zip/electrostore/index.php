<?php

include('includes/header.php');
include('includes/carousel.php');
include('includes/products.php');
include('includes/footer.php');

?>


